package models

type GetAllJamaahByTravelAgent struct {
  token             string    `json:"token"`
  travelagentId     int64     `json:"idTravelagent"`
}
