package controllers

// RegistrationController operations for Registration
// type RegistrationController struct {
// 	beego.Controller
// }

// URLMapping ...
// func (c *RegistrationController) URLMapping() {
// 	c.Mapping("GetAllJamaahTravelagent", c.GetAllJamaahByTravelagent)
// }

// Post ...
// @token
// @TravelAgentId
// @Param	body		body 	models.jamaahtravelagent	true		"body for GetAllJamaahByTravelAgent content"
// @Success 201 {int} models.Travelagent
// @Failure 403 body is empty
// @router / reg [post]
// func(j *GetAllJamaahByTravelagent) RegisterTravel(){
  // token := r.GetString("token")
  // password := r.GetString("password")
// }
