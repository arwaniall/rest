package controllers

import (
  // "myjannah_api/models"
  "myjannah_api/request"
  // "myjannah_api/response"
  // "github.com/astaxie/beego/validation"
  "github.com/astaxie/beego"
  // "myjannah_api/utils"
  // "time"
  "encoding/json"
)

// LoginController operations for Login
type LoginController struct {
	beego.Controller
}

type LoginToken struct {
	Username  string      `json:"username"`
	Token string          `json:"token"`
}

// URLMapping ...
func (c *LoginController) URLMapping() {
	c.Mapping("Post", c.Login)
}

// Login ...
// @Username
// @Password
// @TypeLogin
// @Param	body		body 	models.Login	true		"body for Login content"
// @Success 201 {int} models.Travelagent
// @Failure 403 body is empty
// @router / login [post]
func(l *LoginController) Login(){

  // username := l.GetString("username")
  // password := l.GetString("password")
  // typeLogin := l.GetString("typelogin")
  var loginReq request.LoginRequest
  json.Unmarshal(l.Ctx.Input.RequestBody, &loginReq)
  // l.Ctx.Input.Bind(&loginReq.Username, "username")

  beego.Debug("TESTINg ", loginReq)
  beego.Debug("TESTINg 1 ", loginReq.Username)
  if err := json.Unmarshal(l.Ctx.Input.RequestBody, &loginReq); err == nil {
  //   beego.Debug("TEST  11", err)
  //   beego.Debug("TEST ", loginReq)
    beego.Debug("ERROR ", err)
    // loginReq = {
      // Username :=  l.postForm("username")
      // beego.Debug("Nama ", Username)
    // }
    // password := l.GetString("password")
    // typeLogin := l.GetString("typelogin")
      // beego.Debug("Username is  ", username)
    }
    beego.Debug("ERROR 1 ", err)
  }

  // valid := validation.Validation{}

  //validation
    // valid.Required(username, "username").Message("username must be insert")
    // valid.Required(password, "password").Message("password must be insert")
    // valid.Required(typeLogin, "typeLogin").Message("Type Login must be insert")

  //If Has Error From validation
  // if valid.HasErrors() {
  //     for _, err := range valid.Errors {
  //       l.Ctx.ResponseWriter.WriteHeader(403)
  //       l.Data["json"] = ErrResponse{403001, map[string]string{err.Key: err.Message}}
  //       l.ServeJSON()
  //       return
  //     }
  // }else{
  //   if typeLogin == "TRAVELAGENT" {

      //Check Available Account
      // w, err := models.CheckUserByEmailAndPassword(username, password);
      // if err != nil {
      //   l.Data["json"] = ErrResponse{428001, "Account Not Be Found"}
      //   l.ServeJSON()
      //   return
      // }

      //Check Status Account
    //   if w.Status != "ACTIVE" {
    //     l.Data["json"] = ErrResponse{429001, "Your Account Not Be Activated"}
    //     l.ServeJSON()
    //     return
    //   }
    // }

    //Create Token
    // et := utils.EasyToken{
    //     Username: username,
    //     Expires:  time.Now().Unix() + 3600,
    // }
    // token, err := et.GetToken()
    // if token == "" || err != nil {
    //     l.Data["json"] = ErrResponse{-0, err.Error()}
    // } else {
    //     l.Data["json"] = Response{0, "success.", LoginToken{username, token}}
    // }
    //   l.ServeJSON()
    // }
// }
